package main

import (
	"fmt"
	"sync"
	"time"
)

func main() {
	var mu sync.Mutex

	mu.Lock()//还未进入线程，主线程就已经运行完毕同时执行了解锁操作但没有进行上锁操作，上锁要在主线程之前
	go func() {
		fmt.Println("有点强人锁男")
	}()
	mu.Unlock()
    time.Sleep(time.Second)
}