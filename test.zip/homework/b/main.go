package main

import "fmt"

func main() {
    kk := make(chan int,1)
	kk <- 1
	go func() {
		fmt.Println("下山的路又堵起了")
		<- kk
	}()
	kk <- 2
}