package dao

import (
	"fmt"
	"github.com/jmoiron/sqlx"
	"homework/api"
)
var Db *sqlx.DB//Db数据库连接池
func Menu(){
	api.InitDB()
	fmt.Println("1.login\n","2.register\n","3.exit")
	var option int
	fmt.Scanln(&option)
	switch option {
	case 1:
		api.Login()
		fmt.Println("1.change the password\n","2.exit")
		fmt.Scanln(&option)
		switch option {
		case 1:
			api.Changepassword()
			Step()
		case 2:
			api.Exit()
		}
	case 2:
		api.Register()
		Menu()
	case 3:
		api.Exit()
	default:
		fmt.Println("please write down the right option")
		return
	}
}
func Step()  {
	var option int
	fmt.Println("1.change the password")
	fmt.Scanln(&option)
	switch option {
	case 1:
		api.Changepassword()
		return
	}
}