package main
import (
	"homework/dao"
	_ "github.com/go-sql-driver/mysql"
)
func main()  {
	dao.Menu()
}



