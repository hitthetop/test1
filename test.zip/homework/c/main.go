package main

import "fmt"
var kk chan int
func word(){
	fmt.Println("hello world")
	<-kk
}
func main()  {
	kk = make(chan int,1)
	for i:=1;i<=10;i++ {
		kk <- 1
		go word()
	}
	kk <- 1
}