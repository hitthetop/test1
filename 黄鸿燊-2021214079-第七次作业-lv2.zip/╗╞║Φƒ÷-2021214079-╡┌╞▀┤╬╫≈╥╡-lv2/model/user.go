package model

type Message struct {
	Name string
	Message string
}
type Userinfo struct{
	Name string
	Password string
}
var User struct{
	Name string `db:"id"`
	Password string `db:"password"`
}
var Security struct{
	Name string `db:"name"`
	Questions string `db:"questions"`
	Answers string `db:"answers"`
}