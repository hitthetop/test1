package main
import (
	"Task/One/demo8.2/homework/dao"
	_ "github.com/go-sql-driver/mysql"
)
func main()  {
	dao.Menu()
}



