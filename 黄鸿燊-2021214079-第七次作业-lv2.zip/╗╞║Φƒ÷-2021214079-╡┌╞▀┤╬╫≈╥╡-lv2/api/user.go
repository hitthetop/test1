package api

import (
	"Task/One/demo8.2/homework/model"
	"fmt"
	//"Task/One/demo8.2/homework/cmd"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
)
var cookie model.Userinfo
var Db *sqlx.DB
func Login()  {
	fmt.Print("请输入您的账号：")
	fmt.Scanln(&model.User.Name)
	fmt.Print("请输入您的密码：")
	fmt.Scanln(&model.User.Password)
	var u model.Userinfo
	sqlStr := "select name,password from user where name = ?"
	rowOBJ:= Db.QueryRow(sqlStr, model.User.Name)
	err:=rowOBJ.Scan(&u.Name,&u.Password)
	if err!=nil{
		fmt.Println("账号或密码错误")
		Login()
	}
	if u.Password == model.User.Password{
		fmt.Println("恭喜您登录成功")
	} else{
		fmt.Println("账号或密码错误")
		Login()
	}

	cookie.Name = model.User.Name
}
func Register()  {
	fmt.Print("请输入您的账号：")
	fmt.Scanln(&model.User.Name)
	fmt.Print("请输入您的密码：")
	fmt.Scanln(&model.User.Password)
	r := "insert into user(Name,Password) values (?,?)"
	re,err := Db.Exec(r, model.User.Name, model.User.Password)
	if err != nil{
		fmt.Printf("insert failed,err:%v\n",err)
		return
	}
	newID,err :=re.LastInsertId()
	if err != nil{
		fmt.Printf("get lastinsert id failed,err:%v\n",err)
	}
	fmt.Printf("insert success, the id is %d.\n", newID)
	fmt.Println("congratulations！the ID have changed successfully")
	//为用户创建一个独属于自己的数据库保存留言信息
	fmt.Printf("your messagelist name is %s",model.User.Name)
	CreateTable(model.User.Name)
	fmt.Println("register have been finished,please log again")
}
func Changepassword() {
	fmt.Print("please input your account：")
	fmt.Scanln(&model.User.Name)
	fmt.Print("please input your password：")
	fmt.Scanln(&model.User.Password)
	var u model.Userinfo
	sqlStr := "select name,password from user where name = ?"
	rowOBJ:= Db.QueryRow(sqlStr, model.User.Name)
	err:=rowOBJ.Scan(&u.Name,&u.Password)
	if err!=nil{
		fmt.Println("账号错误")
		Changepassword()
	}
	if u.Password == model.User.Password{
		fmt.Println("恭喜您登录成功")
	} else{
		fmt.Println("密码错误")
		Changepassword()
	}
	fmt.Print("请输入您的账号：")
	fmt.Scanln(&model.Security.Name)
	fmt.Print("请输入您的密保问题：")
	fmt.Scanln(&model.Security.Questions)
	fmt.Print("请输入您的密保答案：")
	fmt.Scanln(&model.Security.Answers)

	str := "insert into security(name,question,answer) values (?,?,?)"

	re, err := Db.Exec(str, model.User.Name, model.Security.Questions, model.Security.Answers)
	if err != nil {
		fmt.Printf("insert failed,err:%v\n", err)
		return
	}
	new, err := re.LastInsertId()
	if err != nil {
		fmt.Printf("set 密保 failed,err:%v\n", err)
	}
	fmt.Printf("insert success, the id is %d.\n", new)
	fmt.Println("恭喜您，密保设置成功")
}