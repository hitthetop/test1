package api

import (
	"Task/One/demo8.2/homework/model"
	"database/sql"
	"fmt"
)
//修改对应个人的mysql
func Leavethemessage()  {
	var u model.Message
	fmt.Println("please input the account number which you want to leave the message to")
	fmt.Scanln(&u.Name)
	fmt.Println("please input the message you want to leave")
	fmt.Scanln(&u.Message)
	sqlStr:= "insert into (?)(message) values(?)"
	rowOBJ:= Db.QueryRow(sqlStr,u.Name,u.Message)
	err:=rowOBJ.Scan(&u.Name)
	if err != nil{
		fmt.Println("账号错误")
	}
	ret,err := Db.Exec(sqlStr)
	if err != nil{
		fmt.Printf("insert failed,err:%v\n",err)
		return
	}
	_,err = ret.LastInsertId()
	if err != nil{
		fmt.Printf("get last id filed,err:%v\n",err)
		return
	}
}
func Query()  {
	var u model.Message
	sqlStr := "select name,message from ? where id > ?"
	rows,err:=Db.Query(sqlStr,cookie.Name,0)
	if err!=nil{
		fmt.Println(err)
		return
	}
	defer rows.Close()
	fmt.Println("以下用户给您留了言")
	for rows.Next(){
		err := rows.Scan(&u.Name,&u.Message)
		if err!=nil{
			fmt.Println(err)
			return
		}
		fmt.Printf("name:%s message:%s\n",u.Name,u.Message)
	}
}
func CreateTable(table string) {
	var db *sql.DB
	sql := `
    DROP TABLE IF EXISTS ` + table + `;
    CREATE TABLE ` + table + `(
        name VARCHAR(64) NULL DEFAULT NULL,
        message VARCHAR(64) NULL DEFAULT NULL,
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;`
	fmt.Println("\n" + sql + "\n")
	smt, err := db.Prepare(sql)
	if err != nil{
		fmt.Println(err)
	}
	smt.Exec()
}