package api

import (
	"fmt"
	"os"
)

func Exit()  {
	fmt.Println("good bye")
	os.Exit(0)
}